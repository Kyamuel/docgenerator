import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api, internal } from "./_generated/api";

export const createDocument = mutation({
  args: {
    documentType: v.union(
      v.literal("scheme_of_work"),
      v.literal("lesson_plan"),
      v.literal("record_of_work"),
      v.literal("iep")
    ),
    teacherName: v.string(),
    tscNumber: v.string(),
    schoolName: v.string(),
    title: v.string(),
    content: v.any(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const documentId = await ctx.db.insert("documents", {
      userId,
      documentType: args.documentType,
      teacherName: args.teacherName,
      tscNumber: args.tscNumber,
      schoolName: args.schoolName,
      title: args.title,
      content: args.content,
      status: "draft",
    });

    // Schedule document generation
    await ctx.scheduler.runAfter(0, internal.documents.generateDocument, {
      documentId,
    });

    return documentId;
  },
});

export const getUserDocuments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    return await ctx.db
      .query("documents")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const getDocument = query({
  args: { documentId: v.id("documents") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const document = await ctx.db.get(args.documentId);
    if (!document || document.userId !== userId) {
      throw new Error("Document not found");
    }

    return document;
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }
    return await ctx.storage.generateUploadUrl();
  },
});

export const uploadCurriculum = mutation({
  args: {
    fileName: v.string(),
    fileId: v.id("_storage"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const uploadId = await ctx.db.insert("curriculumUploads", {
      userId,
      fileName: args.fileName,
      fileId: args.fileId,
      status: "uploaded",
    });

    // Schedule PDF processing
    await ctx.scheduler.runAfter(0, internal.documents.processCurriculumPDF, {
      uploadId,
    });

    return uploadId;
  },
});

export const getCurriculumUploads = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    return await ctx.db
      .query("curriculumUploads")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const getDocumentUrl = query({
  args: { 
    documentId: v.id("documents"),
    fileType: v.union(v.literal("docx"), v.literal("pdf"))
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const document = await ctx.db.get(args.documentId);
    if (!document || document.userId !== userId) {
      throw new Error("Document not found");
    }

    const fileId = args.fileType === "docx" ? document.docxFileId : document.pdfFileId;
    if (!fileId) {
      return null;
    }

    return await ctx.storage.getUrl(fileId);
  },
});
