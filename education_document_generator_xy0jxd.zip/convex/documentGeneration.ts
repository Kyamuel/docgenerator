"use node";

import { v } from "convex/values";
import { internalAction, internalMutation } from "./_generated/server";
import { internal } from "./_generated/api";

// Document generation using docx library
export const generateDocument = internalAction({
  args: { documentId: v.id("documents") },
  handler: async (ctx, args) => {
    try {
      // Update status to generating
      await ctx.runMutation(internal.documents.updateDocumentStatus, {
        documentId: args.documentId,
        status: "generating",
      });

      const document = await ctx.runQuery(internal.documents.getDocumentInternal, {
        documentId: args.documentId,
      });

      if (!document) {
        throw new Error("Document not found");
      }

      // Generate DOCX content based on document type
      const docxBuffer = await generateDocxContent(document);
      
      // Upload DOCX file
      const docxUploadUrl = await ctx.storage.generateUploadUrl();
      const docxResponse = await fetch(docxUploadUrl, {
        method: "POST",
        headers: { "Content-Type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
        body: docxBuffer,
      });
      
      if (!docxResponse.ok) {
        throw new Error("Failed to upload DOCX file");
      }
      
      const { storageId: docxFileId } = await docxResponse.json();

      // Generate PDF from DOCX
      const pdfBuffer = await convertDocxToPdf(docxBuffer);
      
      // Upload PDF file
      const pdfUploadUrl = await ctx.storage.generateUploadUrl();
      const pdfResponse = await fetch(pdfUploadUrl, {
        method: "POST",
        headers: { "Content-Type": "application/pdf" },
        body: pdfBuffer,
      });
      
      if (!pdfResponse.ok) {
        throw new Error("Failed to upload PDF file");
      }
      
      const { storageId: pdfFileId } = await pdfResponse.json();

      // Update document with file IDs
      await ctx.runMutation(internal.documents.updateDocumentFiles, {
        documentId: args.documentId,
        docxFileId,
        pdfFileId,
        status: "completed",
      });

    } catch (error) {
      console.error("Document generation failed:", error);
      await ctx.runMutation(internal.documents.updateDocumentStatus, {
        documentId: args.documentId,
        status: "error",
      });
      throw error;
    }
  },
});

export const processCurriculumPDF = internalAction({
  args: { uploadId: v.id("curriculumUploads") },
  handler: async (ctx, args) => {
    try {
      await ctx.runMutation(internal.documents.updateCurriculumStatus, {
        uploadId: args.uploadId,
        status: "processing",
      });

      const upload = await ctx.runQuery(internal.documents.getCurriculumUploadInternal, {
        uploadId: args.uploadId,
      });

      if (!upload) {
        throw new Error("Upload not found");
      }

      // Get file from storage
      const fileUrl = await ctx.storage.getUrl(upload.fileId);
      if (!fileUrl) {
        throw new Error("File not found in storage");
      }

      // Extract text from PDF
      const extractedData = await extractCurriculumData(fileUrl);

      // Update upload with extracted data
      await ctx.runMutation(internal.documents.updateCurriculumData, {
        uploadId: args.uploadId,
        extractedData,
        status: "completed",
      });

    } catch (error) {
      console.error("PDF processing failed:", error);
      await ctx.runMutation(internal.documents.updateCurriculumStatus, {
        uploadId: args.uploadId,
        status: "error",
      });
      throw error;
    }
  },
});

// Helper functions for document generation
async function generateDocxContent(document: any): Promise<ArrayBuffer> {
  // This would use the docx library to generate Word documents
  // For now, return a simple buffer - will be implemented with proper docx generation
  const content = generateTemplateContent(document);
  return new TextEncoder().encode(content).buffer;
}

async function convertDocxToPdf(docxBuffer: ArrayBuffer): Promise<ArrayBuffer> {
  // This would convert DOCX to PDF using a library like puppeteer or similar
  // For now, return the same buffer - will be implemented with proper PDF conversion
  return docxBuffer;
}

async function extractCurriculumData(fileUrl: string): Promise<any> {
  // This would extract curriculum data from PDF using pdf-parse or similar
  // For now, return mock data structure
  return {
    strands: ["Strand 1", "Strand 2"],
    subStrands: ["Sub-strand 1.1", "Sub-strand 1.2"],
    learningOutcomes: ["Outcome 1", "Outcome 2"],
    learningExperiences: ["Experience 1", "Experience 2"],
    inquiryQuestions: ["Question 1", "Question 2"],
  };
}

function generateTemplateContent(document: any): string {
  const { documentType, teacherName, tscNumber, schoolName, title, content } = document;
  
  switch (documentType) {
    case "scheme_of_work":
      return generateSchemeOfWork(teacherName, tscNumber, schoolName, title, content);
    case "lesson_plan":
      return generateLessonPlan(teacherName, tscNumber, schoolName, title, content);
    case "record_of_work":
      return generateRecordOfWork(teacherName, tscNumber, schoolName, title, content);
    case "iep":
      return generateIEP(teacherName, tscNumber, schoolName, title, content);
    default:
      throw new Error("Unknown document type");
  }
}

function generateSchemeOfWork(teacherName: string, tscNumber: string, schoolName: string, title: string, content: any): string {
  return `SCHEME OF WORK

School: ${schoolName}
Teacher: ${teacherName}
TSC Number: ${tscNumber}
Title: ${title}

${JSON.stringify(content, null, 2)}`;
}

function generateLessonPlan(teacherName: string, tscNumber: string, schoolName: string, title: string, content: any): string {
  return `LESSON PLAN

School: ${schoolName}
Teacher: ${teacherName}
TSC Number: ${tscNumber}
Title: ${title}

${JSON.stringify(content, null, 2)}`;
}

function generateRecordOfWork(teacherName: string, tscNumber: string, schoolName: string, title: string, content: any): string {
  return `RECORD OF WORK COVERED

School: ${schoolName}
Teacher: ${teacherName}
TSC Number: ${tscNumber}
Title: ${title}

${JSON.stringify(content, null, 2)}`;
}

function generateIEP(teacherName: string, tscNumber: string, schoolName: string, title: string, content: any): string {
  return `INDIVIDUALISED EDUCATION PROGRAMME (IEP)

School: ${schoolName}
Teacher: ${teacherName}
TSC Number: ${tscNumber}
Title: ${title}

${JSON.stringify(content, null, 2)}`;
}

export const updateDocumentStatus = internalMutation({
  args: {
    documentId: v.id("documents"),
    status: v.union(
      v.literal("draft"),
      v.literal("generating"),
      v.literal("completed"),
      v.literal("error")
    ),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.documentId, { status: args.status });
  },
});

export const updateDocumentFiles = internalMutation({
  args: {
    documentId: v.id("documents"),
    docxFileId: v.id("_storage"),
    pdfFileId: v.id("_storage"),
    status: v.union(
      v.literal("draft"),
      v.literal("generating"),
      v.literal("completed"),
      v.literal("error")
    ),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.documentId, {
      docxFileId: args.docxFileId,
      pdfFileId: args.pdfFileId,
      status: args.status,
    });
  },
});

export const getDocumentInternal = internalMutation({
  args: { documentId: v.id("documents") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.documentId);
  },
});

export const updateCurriculumStatus = internalMutation({
  args: {
    uploadId: v.id("curriculumUploads"),
    status: v.union(
      v.literal("uploaded"),
      v.literal("processing"),
      v.literal("completed"),
      v.literal("error")
    ),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.uploadId, { status: args.status });
  },
});

export const updateCurriculumData = internalMutation({
  args: {
    uploadId: v.id("curriculumUploads"),
    extractedData: v.any(),
    status: v.union(
      v.literal("uploaded"),
      v.literal("processing"),
      v.literal("completed"),
      v.literal("error")
    ),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.uploadId, {
      extractedData: args.extractedData,
      status: args.status,
    });
  },
});

export const getCurriculumUploadInternal = internalMutation({
  args: { uploadId: v.id("curriculumUploads") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.uploadId);
  },
});
