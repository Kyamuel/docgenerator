import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  documents: defineTable({
    userId: v.id("users"),
    documentType: v.union(
      v.literal("scheme_of_work"),
      v.literal("lesson_plan"),
      v.literal("record_of_work"),
      v.literal("iep")
    ),
    teacherName: v.string(),
    tscNumber: v.string(),
    schoolName: v.string(),
    title: v.string(),
    content: v.any(), // JSON structure for document content
    docxFileId: v.optional(v.id("_storage")),
    pdfFileId: v.optional(v.id("_storage")),
    status: v.union(
      v.literal("draft"),
      v.literal("generating"),
      v.literal("completed"),
      v.literal("error")
    ),
  }).index("by_user", ["userId"]),

  curriculumUploads: defineTable({
    userId: v.id("users"),
    fileName: v.string(),
    fileId: v.id("_storage"),
    extractedData: v.optional(v.any()), // Extracted curriculum data
    status: v.union(
      v.literal("uploaded"),
      v.literal("processing"),
      v.literal("completed"),
      v.literal("error")
    ),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
