import { DocumentType } from "./DocumentGenerator";

interface DocumentTypeSelectorProps {
  onSelect: (type: DocumentType) => void;
}

export function DocumentTypeSelector({ onSelect }: DocumentTypeSelectorProps) {
  const documentTypes = [
    {
      type: "scheme_of_work" as DocumentType,
      title: "Scheme of Work",
      description: "Plan your curriculum delivery with structured weekly breakdowns",
      icon: "📋",
    },
    {
      type: "lesson_plan" as DocumentType,
      title: "Lesson Plan",
      description: "Create detailed individual lesson plans with objectives and activities",
      icon: "📝",
    },
    {
      type: "record_of_work" as DocumentType,
      title: "Record of Work Covered",
      description: "Track and document completed curriculum content",
      icon: "✅",
    },
    {
      type: "iep" as DocumentType,
      title: "Individualised Education Programme (IEP)",
      description: "Develop personalized learning plans for individual students",
      icon: "👤",
    },
  ];

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">Choose Document Type</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {documentTypes.map((docType) => (
          <button
            key={docType.type}
            onClick={() => onSelect(docType.type)}
            className="p-6 bg-white rounded-lg border border-gray-200 hover:border-primary hover:shadow-md transition-all text-left group"
          >
            <div className="flex items-start space-x-4">
              <span className="text-3xl">{docType.icon}</span>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 group-hover:text-primary transition-colors">
                  {docType.title}
                </h3>
                <p className="text-gray-600 mt-2">{docType.description}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
