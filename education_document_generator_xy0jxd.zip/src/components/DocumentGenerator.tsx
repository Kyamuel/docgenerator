import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { DocumentTypeSelector } from "./DocumentTypeSelector";
import { DocumentForm } from "./DocumentForm";
import { DocumentList } from "./DocumentList";
import { CurriculumUpload } from "./CurriculumUpload";

export type DocumentType = "scheme_of_work" | "lesson_plan" | "record_of_work" | "iep";

export function DocumentGenerator() {
  const [selectedType, setSelectedType] = useState<DocumentType | null>(null);
  const [showForm, setShowForm] = useState(false);
  
  const documents = useQuery(api.documents.getUserDocuments) || [];
  const curriculumUploads = useQuery(api.documents.getCurriculumUploads) || [];

  const handleTypeSelect = (type: DocumentType) => {
    setSelectedType(type);
    setShowForm(true);
  };

  const handleFormCancel = () => {
    setShowForm(false);
    setSelectedType(null);
  };

  const handleFormSuccess = () => {
    setShowForm(false);
    setSelectedType(null);
    toast.success("Document generation started!");
  };

  if (showForm && selectedType) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold">
            Create {getDocumentTypeName(selectedType)}
          </h2>
          <button
            onClick={handleFormCancel}
            className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            ← Back
          </button>
        </div>
        
        {selectedType === "scheme_of_work" && (
          <CurriculumUpload uploads={curriculumUploads} />
        )}
        
        <DocumentForm
          documentType={selectedType}
          onSuccess={handleFormSuccess}
          onCancel={handleFormCancel}
          curriculumUploads={curriculumUploads}
        />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <DocumentTypeSelector onSelect={handleTypeSelect} />
      <DocumentList documents={documents} />
    </div>
  );
}

function getDocumentTypeName(type: DocumentType): string {
  switch (type) {
    case "scheme_of_work":
      return "Scheme of Work";
    case "lesson_plan":
      return "Lesson Plan";
    case "record_of_work":
      return "Record of Work Covered";
    case "iep":
      return "Individualised Education Programme (IEP)";
  }
}
