import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { DocumentType } from "./DocumentGenerator";
import { SchemeOfWorkForm } from "./forms/SchemeOfWorkForm";
import { LessonPlanForm } from "./forms/LessonPlanForm";
import { RecordOfWorkForm } from "./forms/RecordOfWorkForm";
import { IEPForm } from "./forms/IEPForm";

interface DocumentFormProps {
  documentType: DocumentType;
  onSuccess: () => void;
  onCancel: () => void;
  curriculumUploads: any[];
}

export function DocumentForm({ documentType, onSuccess, onCancel, curriculumUploads }: DocumentFormProps) {
  const [basicInfo, setBasicInfo] = useState({
    teacherName: "",
    tscNumber: "",
    schoolName: "",
    title: "",
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const createDocument = useMutation(api.documents.createDocument);

  const handleBasicInfoChange = (field: string, value: string) => {
    setBasicInfo(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (content: any) => {
    if (!basicInfo.teacherName || !basicInfo.tscNumber || !basicInfo.schoolName || !basicInfo.title) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    try {
      await createDocument({
        documentType,
        teacherName: basicInfo.teacherName,
        tscNumber: basicInfo.tscNumber,
        schoolName: basicInfo.schoolName,
        title: basicInfo.title,
        content,
      });
      onSuccess();
    } catch (error) {
      console.error("Failed to create document:", error);
      toast.error("Failed to create document. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="space-y-6">
        {/* Basic Information */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Basic Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Teacher's Name *
              </label>
              <input
                type="text"
                value={basicInfo.teacherName}
                onChange={(e) => handleBasicInfoChange("teacherName", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter teacher's name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                TSC Number *
              </label>
              <input
                type="text"
                value={basicInfo.tscNumber}
                onChange={(e) => handleBasicInfoChange("tscNumber", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter TSC number"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                School Name *
              </label>
              <input
                type="text"
                value={basicInfo.schoolName}
                onChange={(e) => handleBasicInfoChange("schoolName", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter school name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Document Title *
              </label>
              <input
                type="text"
                value={basicInfo.title}
                onChange={(e) => handleBasicInfoChange("title", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter document title"
              />
            </div>
          </div>
        </div>

        {/* Document-specific form */}
        <div>
          {documentType === "scheme_of_work" && (
            <SchemeOfWorkForm
              onSubmit={handleSubmit}
              onCancel={onCancel}
              isSubmitting={isSubmitting}
              curriculumUploads={curriculumUploads}
            />
          )}
          {documentType === "lesson_plan" && (
            <LessonPlanForm
              onSubmit={handleSubmit}
              onCancel={onCancel}
              isSubmitting={isSubmitting}
            />
          )}
          {documentType === "record_of_work" && (
            <RecordOfWorkForm
              onSubmit={handleSubmit}
              onCancel={onCancel}
              isSubmitting={isSubmitting}
            />
          )}
          {documentType === "iep" && (
            <IEPForm
              onSubmit={handleSubmit}
              onCancel={onCancel}
              isSubmitting={isSubmitting}
            />
          )}
        </div>
      </div>
    </div>
  );
}
