import { useState } from "react";

interface RecordOfWorkFormProps {
  onSubmit: (content: any) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}

interface WorkRecord {
  week: string;
  date: string;
  strand: string;
  subStrand: string;
  learningOutcomes: string;
  activities: string;
  assessment: string;
  remarks: string;
}

export function RecordOfWorkForm({ onSubmit, onCan