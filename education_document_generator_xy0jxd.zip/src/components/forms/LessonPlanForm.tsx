import { useState } from "react";

interface LessonPlanFormProps {
  onSubmit: (content: any) => void;
  onCancel: () => void;
  isSubmitting: boolean;
}

interface LessonPlan {
  subject: string;
  class: string;
  date: string;
  duration: string;
  strand: string;
  subStrand: string;
  learningOutcomes: string;
  keyInquiryQuestions: string;
  coreCompetencies: string;
  values: string;
  introduction: string;
  development: string;
  conclusion: string;
  assessment: string;
  resources: string;
  reflection: string;
}

export function LessonPlanForm({ onSubmit, onCancel, isSubmitting }: LessonPlanFormProps) {
  const [lessonPlan, setLessonPlan] = useState<LessonPlan>({
    subject: "",
    class: "",
    date: "",
    duration: "",
    strand: "",
    subStrand: "",
    learningOutcomes: "",
    keyInquiryQuestions: "",
    coreCompetencies: "",
    values: "",
    introduction: "",
    development: "",
    conclusion: "",
    assessment: "",
    resources: "",
    reflection: "",
  });

  const updateField = (field: keyof LessonPlan, value: string) => {
    setLessonPlan(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(lessonPlan);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Lesson Plan Details</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Subject
            </label>
            <input
              type="text"
              value={lessonPlan.subject}
              onChange={(e) => updateField("subject", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Enter subject"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Class
            </label>
            <input
              type="text"
              value={lessonPlan.class}
              onChange={(e) => updateField("class", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Enter class"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date
            </label>
            <input
              type="date"
              value={lessonPlan.date}
              onChange={(e) => updateField("date", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Duration
            </label>
            <input
              type="text"
              value={lessonPlan.duration}
              onChange={(e) => updateField("duration", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="e.g., 40 minutes"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Strand
            </label>
            <input
              type="text"
              value={lessonPlan.strand}
              onChange={(e) => updateField("strand", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Enter strand"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Sub-strand
            </label>
            <input
              type="text"
              value={lessonPlan.subStrand}
              onChange={(e) => updateField("subStrand", e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Enter sub-strand"
            />
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Learning Outcomes
            </label>
            <textarea
              value={lessonPlan.learningOutcomes}
              onChange={(e) => updateField("learningOutcomes", e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Enter learning outcomes"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Key Inquiry Questions
            </label>
            <textarea
              value={lessonPlan.keyInquiryQuestions}
              onChange={(e) => updateField("keyInquiryQuestions", e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Enter key inquiry questions"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Core Competencies
              </label>
              <input
                type="text"
                value={lessonPlan.coreCompetencies}
                onChange={(e) => updateField("coreCompetencies", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter core competencies"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Values
              </label>
              <input
                type="text"
                value={lessonPlan.values}
                onChange={(e) => updateField("values", e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Enter values"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Introduction
            </label>
            <textarea
              value={lessonPlan.introduction}
              onChange={(e) => updateField("introduction", e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Describe lesson introduction activities"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Development
            </label>
            <textarea
              value={lessonPlan.development}
              onChange={(e) => updateField("development", e.target.value)}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Describe main lesson activities and content delivery"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Conclusion
            </label>
            <textarea
              value={lessonPlan.conclusion}
              onChange={(e) => updateField("conclusion", e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Describe lesson conclusion and wrap-up activities"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Assessment
            </label>
            <textarea
              value={lessonPlan.assessment}
              onChange={(e) => updateField("assessment", e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Describe assessment methods and criteria"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Learning Resources
            </label>
            <textarea
              value={lessonPlan.resources}
              onChange={(e) => updateField("resources", e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="List required resources and materials"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Reflection
            </label>
            <textarea
              value={lessonPlan.reflection}
              onChange={(e) => updateField("reflection", e.target.value)}
              rows={2}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              placeholder="Space for post-lesson reflection (can be filled after teaching)"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end space-x-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary-hover transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? "Generating..." : "Generate Document"}
        </button>
      </div>
    </form>
  );
}
