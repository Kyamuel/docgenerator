import { useState } from "react";

interface SchemeOfWorkFormProps {
  onSubmit: (content: any) => void;
  onCancel: () => void;
  isSubmitting: boolean;
  curriculumUploads: any[];
}

interface WeekEntry {
  week: string;
  strand: string;
  subStrand: string;
  learningOutcomes: string;
  learningExperiences: string;
  keyInquiryQuestions: string;
  coreCompetencies: string;
  values: string;
  assessmentRubric: string;
  learningResources: string;
}

export function SchemeOfWorkForm({ onSubmit, onCancel, isSubmitting, curriculumUploads }: SchemeOfWorkFormProps) {
  const [selectedCurriculum, setSelectedCurriculum] = useState<string>("");
  const [weeks, setWeeks] = useState<WeekEntry[]>([
    {
      week: "1",
      strand: "",
      subStrand: "",
      learningOutcomes: "",
      learningExperiences: "",
      keyInquiryQuestions: "",
      coreCompetencies: "",
      values: "",
      assessmentRubric: "",
      learningResources: "",
    },
  ]);

  const addWeek = () => {
    setWeeks([
      ...weeks,
      {
        week: (weeks.length + 1).toString(),
        strand: "",
        subStrand: "",
        learningOutcomes: "",
        learningExperiences: "",
        keyInquiryQuestions: "",
        coreCompetencies: "",
        values: "",
        assessmentRubric: "",
        learningResources: "",
      },
    ]);
  };

  const removeWeek = (index: number) => {
    if (weeks.length > 1) {
      setWeeks(weeks.filter((_, i) => i !== index));
    }
  };

  const updateWeek = (index: number, field: keyof WeekEntry, value: string) => {
    setWeeks(weeks.map((week, i) => (i === index ? { ...week, [field]: value } : week)));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      selectedCurriculum,
      weeks,
    });
  };

  const completedUploads = curriculumUploads.filter(upload => upload.status === "completed");

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Scheme of Work Details</h3>
        
        {completedUploads.length > 0 && (
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Use Curriculum Data (Optional)
            </label>
            <select
              value={selectedCurriculum}
              onChange={(e) => setSelectedCurriculum(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            >
              <option value="">Select curriculum upload...</option>
              {completedUploads.map((upload) => (
                <option key={upload._id} value={upload._id}>
                  {upload.fileName}
                </option>
              ))}
            </select>
          </div>
        )}

        <div className="space-y-6">
          {weeks.map((week, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-medium">Week {week.week}</h4>
                {weeks.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeWeek(index)}
                    className="text-red-600 hover:text-red-800 text-sm"
                  >
                    Remove Week
                  </button>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Strand
                  </label>
                  <input
                    type="text"
                    value={week.strand}
                    onChange={(e) => updateWeek(index, "strand", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter strand"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Sub-strand
                  </label>
                  <input
                    type="text"
                    value={week.subStrand}
                    onChange={(e) => updateWeek(index, "subStrand", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter sub-strand"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Specific Learning Outcomes
                  </label>
                  <textarea
                    value={week.learningOutcomes}
                    onChange={(e) => updateWeek(index, "learningOutcomes", e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter learning outcomes"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Suggested Learning Experiences
                  </label>
                  <textarea
                    value={week.learningExperiences}
                    onChange={(e) => updateWeek(index, "learningExperiences", e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter learning experiences"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Key Inquiry Questions
                  </label>
                  <textarea
                    value={week.keyInquiryQuestions}
                    onChange={(e) => updateWeek(index, "keyInquiryQuestions", e.target.value)}
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter key inquiry questions"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Core Competencies
                  </label>
                  <input
                    type="text"
                    value={week.coreCompetencies}
                    onChange={(e) => updateWeek(index, "coreCompetencies", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter core competencies"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Values
                  </label>
                  <input
                    type="text"
                    value={week.values}
                    onChange={(e) => updateWeek(index, "values", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter values"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Assessment Rubric
                  </label>
                  <input
                    type="text"
                    value={week.assessmentRubric}
                    onChange={(e) => updateWeek(index, "assessmentRubric", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter assessment rubric"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Learning Resources
                  </label>
                  <input
                    type="text"
                    value={week.learningResources}
                    onChange={(e) => updateWeek(index, "learningResources", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="Enter learning resources"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <button
          type="button"
          onClick={addWeek}
          className="mt-4 px-4 py-2 text-primary border border-primary rounded-md hover:bg-primary hover:text-white transition-colors"
        >
          Add Another Week
        </button>
      </div>

      <div className="flex justify-end space-x-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary-hover transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? "Generating..." : "Generate Document"}
        </button>
      </div>
    </form>
  );
}
